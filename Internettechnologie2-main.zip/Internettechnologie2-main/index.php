<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Startseite für IT2 im SoSe 2024</title>
</head>

<body>
	<!--- Kommentar für die Dokumentation des HTML Codes--->
<h1>Herzlich Willkommen!</h1>
<p>Die Verlinkungen auf die einzelnen Wochen sind nicht mehr aktiv. Der Grund ist, dass</p>
<p>aufgrund der Einführung in JavaScript viele Dateien vorhanden sein werden. Die Videos in der Playlist haben</p>
<p>im Videotitel den Dateinamen enthalten, auf die sich das Video bezieht. Ebenfalls sind vorerst alle PHP-Dateien entfernt, damit sie nicht so verwirren.</p>
<p>Somit ist diese Seite vorerst nicht wichtig und wird nicht weiter gepflegt.<br>
</p>
</body>
</html>
// JavaScript Document
// Arbeiten mit Zeichenketten

let modul='Internettechnologie 2';
console.log(modul.length);

for (let index=modul.length-1; index>=0;index--)
	 {
		console.log(modul[index]);
	}
// JavaScript Document

function gleichungLoesen()
	{
	
	}

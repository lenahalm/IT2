// JavaScript Document

function berechnen()
{
 	alert("Berechnung wird ausgeführt");
}
// JavaScript Document

let meinAlter= ; // Benötigst du die einfachen Anführungszeichen?
let meinVorname = ;
let ???			// ersetze die ??? durch einen passenden Variablennamen für deinen Nachnamen und initialisiere die Variable damit.

let meldung =''; // Formuliere die Zeichenkette so, dass bspw. folgendes ausgegeben wird: Mein Name ist Matthias Hoffmann und ich bin 27 Jahre alt. Verwende für den Vornamen, Nachnamen sowie das Alter nur die Variablen.   

console.log(meldung);




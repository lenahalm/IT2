// JavaScript Document
// Arbeiten mit while-Schleifen

let schleifenzaehler=14;
do
	{
		console.log(schleifenzaehler);
		schleifenzaehler++;
	}  while (schleifenzaehler<10);

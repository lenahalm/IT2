// JavaScript Document
// Operatoren für das Arbeiten mit Zahlen

let o1=2;
let o2=9;
let ergebnisAddition=o1+o2;
let ergebnisModulo= o1%o2;
o1++; //Inkrement-Operator
o1=o1+4
o1--; // Dekrement-Operator

console.log(o1);





// JavaScript Document
// Arbeiten mit Arrays.

const studiengaenge = new Array('Medienwirtschaft & Journalismus','Wirtschaftsingenieurwesen','Wirtschaftsinformatik','UX/AR');

for(let schleifenzaehler=0; schleifenzaehler<studiengaenge.length;schleifenzaehler++)
	{
		console.log(studiengaenge[schleifenzaehler]);
	}



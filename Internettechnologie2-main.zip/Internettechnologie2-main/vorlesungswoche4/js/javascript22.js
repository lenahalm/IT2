// JavaScript Document
// Arbeiten mit Zeichenketten

let modul='Internettechnologie 2';

// Erste Vorkommen eines Zeichen suchen und Position als Ergebnis erhalten
console.log(modul.indexOf('t',3));

console.log(modul.indexOf('inter'));
// Letztes Vorkommen suchen
console.log(modul.lastIndexOf('o'));
// Zeichen mit Slice extrahieren
console.log(modul.slice(8));

// JavaScript Document
// Arbeiten mit Arrays.

const nachnamen = new Array('Müller','Meyer','Schulze','Hoffmann');

console.log(nachnamen.length); // length ermittelt die Anzahl der Elemente im Array
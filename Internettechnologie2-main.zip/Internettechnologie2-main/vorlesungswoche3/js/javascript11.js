// JavaScript Document
// Arbeiten mit Arrays.
let name='Andreas';
let isUser=true;
for(let schleifenzaehler=1; schleifenzaehler<=3;schleifenzaehler++)
	{
		console.log(schleifenzaehler);
	}

// JavaScript Document

const menueStrukturStudent3 = [
    new MenuPunkt('Startseite', '../index.html'),
    new MenuPunkt('unsere Anwendungen', '', [
        new MenuPunkt('Anwendung Student 1', '../student1/index.html'),
        new MenuPunkt('Anwendung Student 2', '../student2/index.html'),
		new MenuPunkt('Anwendung Student 3', '../student3/index.html')
    ]),
];

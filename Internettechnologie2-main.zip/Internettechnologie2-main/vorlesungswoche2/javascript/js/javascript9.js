// JavaScript Document
// Arbeiten mit Schleifen, hier Zählschleife

for(let sz=1; sz<=20;sz=sz+3)
	{
		console.log(sz);
	}


// JavaScript Document

let semester=3;
let meldung ='Herzlich Willkommen in \'IT2\' im ${semester}. Semester';

console.log(meldung);




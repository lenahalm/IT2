// JavaScript Document
// Arbeiten mit Arrays.
const kontakte = [ 
			{
				vorname:'Bernd',
				nachname:'Müller',
				ort:'Wilhelmshaven'
			},
			{
				vorname:'Ulrich',
				nachname:'Müller',
				ort:'Oldenburg'
			},
			{
				vorname:'Olaf',
				nachname:'Silbereisen',
				ort:'Bremen'
			}
		]
console.log(kontakte.length); // length ermittelt die Anzahl der Elemente im Array
console.log(kontakte[2].vorname);